package dn;

public class DominoPlacement{
	int coordX;
	int coordY;
	int rotation;

	//On cr�e une matrice 9x9 de String

	String [][] grid = new String [9][9];
	
	
	public static void dominoRepresentation(Domino dom){
		
	}
}
